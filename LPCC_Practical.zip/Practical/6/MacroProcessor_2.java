//////////////////////// MNT MDT /////////////////////

// import java.util.ArrayList;
import java.util.HashMap;
// import java.util.List;

// public class MacroProcessor_2{
    
//     public static void main(String[] args) {
//         List<String> sourceCode = new ArrayList<>();
//         sourceCode.add("LOAD A");
//         sourceCode.add("STORE B");
//         sourceCode.add("MACRO ABC");
//         sourceCode.add("LOAD p");
//         sourceCode.add("SUB q");
//         sourceCode.add("MEND");
//         sourceCode.add("MACRO ADD1 ARG");
//         sourceCode.add("LOAD X");
//         sourceCode.add("STORE ARG");
//         sourceCode.add("MEND");
//         sourceCode.add("MACRO ADD5 A1, A2, A3");
//         sourceCode.add("STORE A2");
//         sourceCode.add("ADD1 5");
//         sourceCode.add("ADD1 10");
//         sourceCode.add("LOAD A1");
//         sourceCode.add("LOAD A3");
//         sourceCode.add("MEND");
//         sourceCode.add("ABC");
//         sourceCode.add("ADD5 D1, D2, D3");
//         sourceCode.add("END");
        
//         HashMap<String, String> macroDefinitionTable = new HashMap<>();
//         HashMap<String, String> macroNameTable = new HashMap<>();
        
//         String currentMacroName = "";
//         StringBuilder currentMacroDefinition = new StringBuilder();
        
//         for (String line : sourceCode) {
//             if (line.startsWith("MACRO")) {
//                 currentMacroName = line.split("\\s+")[1];
//             } 
//             else if (line.equals("MEND")) {
//                 macroDefinitionTable.put(currentMacroName, currentMacroDefinition.toString());
//                 macroNameTable.put(currentMacroName, "");
//                 currentMacroName = "";
//                 currentMacroDefinition.setLength(0);
//             } 
//             else if (!currentMacroName.isEmpty()) {
//                 currentMacroDefinition.append(line).append("\n");
//             }
//         }
        


//         // Print MDT
//         System.out.println("Macro Definition Table (MDT):");
//         for (String macroName : macroDefinitionTable.keySet()) {
//             String macroDefinition = macroDefinitionTable.get(macroName);
//             System.out.println(macroName + ":");
//             System.out.println(macroDefinition);
//             System.out.println();
//         }
        
//         // Print MNT
//         System.out.println("Macro Name Table (MNT):");
//         for (String macroName : macroNameTable.keySet()) {
//             System.out.println(macroName);
//         }
//     }
// }

class MacroProcessor_2{
    public static void main(String[] args) {
        String[] sourceCode = {
            "LOAD A",
            "STORE B",
            "MACRO ABC",
            "LOAD p",
            "SUB q",
            "MEND",
            "MACRO ADD1 ARG",
            "LOAD X",
            "STORE ARG",
            "MEND",
            "MACRO ADD5 A1,A2,A3",
            "STORE A2",
            "ADD1 5",
            "ADD1 10",
            "LOAD A1",
            "LOAD A3",
            "MEND",
            "ABC",
            "ADD5 D1,D2,D3",
            "END"
        };

        HashMap<String,String> macroDefinationTbl = new HashMap<>();
        HashMap<String,String> macroNameTbl = new HashMap<>();

        String currentMacroName = "";
        String currrentParams = "";
        StringBuilder currMacroDefination= new StringBuilder();

        for(String line : sourceCode){
            String [] tokens = line.split("\\s+");
            if(tokens[0].equals("MACRO")){
                currentMacroName = tokens[1];
                if(tokens.length>2)
                    currrentParams = tokens[2];
            }
            else if(tokens[0].equals("MEND")){
                macroDefinationTbl.put(currentMacroName,currMacroDefination.toString());
                macroNameTbl.put(currentMacroName,currrentParams);
                currMacroDefination.setLength(0);
                currrentParams = "";
                currentMacroName="";
            }
            else if(currentMacroName.length()>1){
                currMacroDefination.append(line).append("\n");
            }
        }


        // MDT
        System.out.println("Macro Definition Table : \n");
        for(String macroName : macroDefinationTbl.keySet()){
            System.out.println(macroName);
            System.out.println(macroDefinationTbl.get(macroName)+"\n");
     
        }

        // MNT
        System.out.println("MNT : ");
        for(String macroName : macroNameTbl.keySet()){
            System.out.print(macroName+"\t");
            System.out.println(macroNameTbl.get(macroName));
        }
    }


   
}